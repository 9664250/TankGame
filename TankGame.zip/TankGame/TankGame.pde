// Cassandra Knoll || Apr 14 2026 || Tank Game
PImage bg;
Tank tank1; //declaring tank's name

void setup() {
  size(750, 750);
  bg = loadImage("bg1.png");
  tank1 = new Tank();
}

void draw () {
  background(127);
  imageMode(CORNER);
  image(bg, 0, 0);
  tank1.display();
}

void keyPressed() {
  if (key == 'w') {
    tank1.move('w');
  } else if (key == 'a') {
      tank1.move('a');
  } else if (key == 'd') {
        tank1.move('d');
  } else if (key == 's') {
          tank1.move('s');
        }
      }
